module.exports={
/*
* This file contains the configurations information of Twitter login app.
* It consists of Twitter app information, database information.
*/
        "fbLogin" : {
            "FB_CLIENT_ID"         :   "151831851662530",
            "FB_CLIENT_SECRET"     :   "e1f6c04018b2ea518d806b0f2bf4dcf5",
            "FB_callback_url"      :   "http://localhost:3000/login/facebook/return",
        
        },
	'googleAuth' : {
            'clientID'      : '332013660994-02uigs2712td7sqhrj33nu6galg582q2.apps.googleusercontent.com',
            'clientSecret'  : 'kYRI5SjDnv8G3hgKFLFxCgry',
            'callbackURL'   : 'http://localhost:3000/auth/google/callback'
        },
        "dbCred" :{
            "use_database"          :   "true",
	"host"                  :   "localhost",
	"username"              :   "root",
	"password"              :   "root",
	"database"              :   "todolistapi"
        }

}
