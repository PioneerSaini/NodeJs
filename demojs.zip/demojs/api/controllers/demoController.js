/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var getList = function(req, res, next){
    //console.log(req.query.a);
    return res.json({'helo':'done'});
}
var getListNext = function(req, res, next){
    return res.json({'helo':'done next'});
}


module.exports = {
    getList:getList,
    getListNext:getListNext
};

