/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var app             = require('express')();
var routes          = require('./api/routes/routes');
var fbRoutes          = require('./api/routes/fbRoutes');
var gmailRoutes          = require('./api/routes/gmailRoutes');
var mongoose            =   require('mongoose');
app.set('views', __dirname + '/api/views');
app.set('view engine', 'ejs');

// mongoose instance connection url connection
mongoose.Promise    =   global.Promise;
mongoose.connect('mongodb://localhost/Tododb'); 

app.use(function (req, res, next) {
    //console.log(req.query);
    next();
});

app.use('/task',routes);
//app.use('/', fbRoutes);
app.use('/', gmailRoutes);
app.use(function(req, res) {
  res.status(404).send({url: req.originalUrl + ' not found'})
});







app.listen(3000, function(){
    console.log('Node Server Listen');
});


